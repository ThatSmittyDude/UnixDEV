sudo apt update
sudo apt upgrade -y
sudo apt install btop htop nasm yasm gcc gdb gfortran gnucobol z80asm tree zip unzip openssh-server openssh-client net-tools nmap p7zip zsh ksh build-essential binwalk
