#include <iostream>
int main(){
	double sum, input1, input2, input3, input4, input5, input6, input7, input8, input9, input10, input11, input12;
	std::cout << "Input number press enter to input the next number 12 numnbers max \n";

	std::cout << "1.	";
	std::cin >> input1;

	std::cout << "2.	";
	std::cin >> input2;

	std::cout << "3.	";
	std::cin >> input3;

	std::cout << "4.	";
	std::cin >> input4;

	std::cout << "5.	";
	std::cin >> input5;

	std::cout << "6.	";
	std::cin >> input6;

	std::cout << "7.	";
	std::cin >> input7;

	std::cout << "8.	";
	std::cin >> input8;

	std::cout << "9.	";
	std::cin >> input9;

	std::cout << "10.	";
	std::cin >> input10;

	std::cout << "11.	";
	std::cin >> input11;

	std::cout << "12.	";
	std::cin >> input12;

		sum = input1 + input2 + input3 + input4 + input5 + input6 + input7 + input8 + input9 + input10 + input11 + input12;
		std::cout << "Total: " << sum << std::endl;
		return 0;
}
