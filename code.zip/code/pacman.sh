sudo pacman -Syu -y
sudo pacman -S nasm yasm gcc gdb gcc-fortran btop htop tree zip unzip openssh base-devel texinfo nmap net-tools tmux zsh ksh binwalk
