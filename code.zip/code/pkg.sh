sudo pkg update
sudo pkg upgrade -y
sudo pkg install btop htop gcc gdb nasm yasm tree nmap zip unzip z80asm zsh ksh binwalk
